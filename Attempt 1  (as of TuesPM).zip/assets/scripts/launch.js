



function tryLaunch() {
    var launchOk = 1
    var msg ="";
    var objectMessage = document.getElementById('msg');
    
    if (parking == 1) {
        launchOk = 0;
        msg = "Parking break engaged";
    }

    if (battery == 0) {
        launchOk = 0;
        msg ="Battery not charged.";
    }

    if (trac == 1) {
        launchOk = 0;
        msg ="Disable traction control.";
    }

    if (gasLevel == 0) {
        launchOk = 0;
        msg ="Need gas.";
    }

    if (intMode < 3) {
        launchOk = 0;
        msg = "Must be in Sport mode";
    }

    if (launchOk == 1) {
        Display graphic
        Play racing sound
    } else { /* not launch */
        objectMessage.innerText = msg
        new Audio (./assets/media/Sputter.mp3) play();

    }
}
